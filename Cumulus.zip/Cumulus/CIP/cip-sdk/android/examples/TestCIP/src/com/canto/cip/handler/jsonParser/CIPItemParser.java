package com.canto.cip.handler.jsonParser;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.canto.cip.object.structure.CIPCategory;
import com.canto.cip.object.structure.CIPEnum;
import com.canto.cip.object.structure.CIPItem;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */
/**
 * parses the json-response from cip.
 */
public class CIPItemParser extends AbstractJsonParser<List<CIPItem>>
{
	private static final String TAG = CIPItemParser.class.getSimpleName();

	@Override
	public List<CIPItem> parse(String jsonString)
	{
		List<CIPItem> result = null;
		try
		{
			result = new ArrayList<CIPItem>();

			JSONObject jsonObect = new JSONObject(jsonString);

			JSONArray items = jsonObect.getJSONArray(RESULT_ITEMS_JSON_IDENTIFIER);
			if (items != null)
			{
				for (int i = 0; i < items.length(); i++)
				{
					CIPItem currentCipItem = new CIPItem();
					JSONObject currentObject = items.getJSONObject(i);
					currentCipItem.setRecordName(currentObject.getString(RECORD_NAME_JSON_IDENTIFIER));
					if (!currentObject.isNull(NOTES_JSON_IDENTIFIER))
					{
						currentCipItem.setNotes(currentObject.getString(NOTES_JSON_IDENTIFIER));
					}
					currentCipItem.setStatus(enumFromJSON (currentObject, STATUS_JSON_IDENTIFIER));
					currentCipItem.setRating(enumFromJSON (currentObject, RATING_JSON_IDENTIFIER));
					currentCipItem.setDataSize(dataSizeFromJSON (currentObject, ASSET_DATA_SIZE_LONG_JSON_IDENTIFIER));
					currentCipItem.setId(currentObject.getInt(ID_JSON_IDENTIFIER));
					currentCipItem.setFileFormat(currentObject.getString(FILE_FORMAT_JSON_IDENTIFIER));					
					currentCipItem.setAssetModificationDate(dateFromJSON(currentObject, ASSET_MODIFICATION_DATE_JSON_IDENTIFIER));
					result.add(currentCipItem);
				}
			}
		}
		catch (JSONException e)
		{
			Log.e(TAG, e.getMessage(), e);
		}
		return result;
	}

	private CIPEnum enumFromJSON(JSONObject jsonObject, String member)
	{
		CIPEnum enumValue = new CIPEnum();
		try
		{
			if (!jsonObject.isNull(member))
			{
				JSONObject enumObject = null;
				try
				{
					JSONArray enumArrayObject = jsonObject.getJSONArray(member);
					enumObject = enumArrayObject.getJSONObject(0);
				}
				catch (Exception e)
				{
					enumObject = jsonObject.getJSONObject(member);
				}
				if (enumValue != null)
				{
					enumValue.setDisplayString(enumObject.getString(DISPLAYSTRING_JSON_IDENTIFIER));
					enumValue.setValue(enumObject.getString(ID_JSON_IDENTIFIER));
				}
			}
		}
		catch (JSONException e)
		{
			Log.e(TAG, e.getMessage(), e);
		}
		return enumValue;
	}

	private CIPEnum dataSizeFromJSON(JSONObject jsonObject, String member)
	{
		CIPEnum enumValue = new CIPEnum();
		try
		{
			if (!jsonObject.isNull(member))
			{
				JSONObject enumObject = jsonObject.getJSONObject(member);
				enumValue.setDisplayString(enumObject.getString(DISPLAYSTRING_JSON_IDENTIFIER));
				enumValue.setValue(enumObject.getString(VALUE_JSON_IDENTIFIER));
			}
		}
		catch (JSONException e)
		{
			Log.e(TAG, e.getMessage(), e);
		}
		return enumValue;
	}

	private Date dateFromJSON(JSONObject jsonObject, String member)
	{
		Date dateValue = null;
		try
		{
			if (!jsonObject.isNull(member))
			{
				String stringValue = jsonObject.getString(member).replaceAll("[^0-9]", ""); //$NON-NLS-1$ //$NON-NLS-2$;
				dateValue = new Date(Long.parseLong(stringValue));
			}
		}
		catch (NumberFormatException nfex)
		{
			Log.e(TAG, nfex.getMessage(), nfex);
		}
		catch (JSONException e)
		{
			Log.e(TAG, e.getMessage(), e);
		}
		return dateValue;
	}
}
