package com.canto.cip.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import com.canto.cip.R;
import com.canto.cip.manager.CIPManager;
import com.canto.cip.task.CIPImageLoader;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */
public class CIPImagePreviewActivity extends Activity
{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		Intent intent = getIntent();
		Integer cipItemId = intent.getIntExtra(CIPThumbnailActivity.CIPITEM_ID_IDENTIFIER, -1);
		setContentView(R.layout.cip_preview);
		ImageView imageView = (ImageView) findViewById(R.id.cip_preview_container);
		imageView.setDrawingCacheEnabled(true);
		CIPImageLoader loader = new CIPImageLoader(imageView);

		String request = CIPManager.getPreviewRequest(CIPManager.cipCatalogAlias, cipItemId, 1024);

		loader.execute(request);
	}
}
