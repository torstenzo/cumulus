package com.canto.cip.activities;

import java.io.IOException;
import java.util.List;

import org.apache.http.client.ClientProtocolException;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

import com.canto.cip.R;
import com.canto.cip.adapter.CIPThumbnailListAdapter;
import com.canto.cip.connection.CIPConnector;
import com.canto.cip.handler.jsonParser.CIPItemParser;
import com.canto.cip.manager.CIPManager;
import com.canto.cip.object.structure.CIPItem;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */
public class CIPThumbnailActivity extends Activity implements OnItemClickListener
{
	private static final String TAG = CIPThumbnailActivity.class.getSimpleName();

	public static final String CIPITEM_ID_IDENTIFIER = "com.canto.cip.item.id"; //$NON-NLS-1$

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.cip_thumbnail);
		Intent intent = getIntent();

		String request = null;
		CIPConnector<List<CIPItem>> connector = new CIPConnector<List<CIPItem>>();

		if (intent.hasExtra(CIPQuicksearchActivity.QUICKSEARCH_STRING_IDENTIFIER))
		{
			String searchTerm = intent.getExtras().getString(CIPQuicksearchActivity.QUICKSEARCH_STRING_IDENTIFIER);

			request = CIPManager.getQuicksearchRequest(CIPManager.cipCatalogAlias, CIPManager.cipFieldView, searchTerm);
		}
		else if (intent.hasExtra(CIPCategoriesActivity.CATEGORY_ID_IDENTIFIER))
		{
			int categoryId = intent.getIntExtra(CIPCategoriesActivity.CATEGORY_ID_IDENTIFIER, -1);
			CIPManager.getCategoriesByIdRequest(CIPManager.cipCatalogAlias, categoryId);
			request = CIPManager.getRecordsFromCategoryRequest(CIPManager.cipCatalogAlias, CIPManager.cipFieldView,
					categoryId);
		}

		try
		{
			List<CIPItem> searchResult = connector.sendRequest(request, new CIPItemParser());
			ListView listView = (ListView) findViewById(R.id.cip_thumbail_list);
			listView.setOnItemClickListener(this);
			listView.setAdapter(new CIPThumbnailListAdapter(this, R.layout.cip_thumbnaill_list, searchResult));

		}
		catch (ClientProtocolException e)
		{
			Log.e(TAG, e.getMessage(), e);
		}
		catch (IOException e)
		{
			Log.e(TAG, e.getMessage(), e);
		}
	}

	public void onItemClick(AdapterView<?> adapter, View parent, int position, long id)
	{
		CIPItem currentCipItem = (CIPItem) adapter.getItemAtPosition(position);
		Intent intent = new Intent().setClass(getApplicationContext(), CIPImagePreviewActivity.class);
		intent.putExtra(CIPITEM_ID_IDENTIFIER, currentCipItem.getId().intValue());
		startActivity(intent);
	}
}
