package com.canto.cip.manager;

import java.net.URLEncoder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */
public class CIPManager
{
	private static final String TAG = CIPManager.class.getSimpleName();

	// TODO: replace with cip-server url
	public static final String cipBaseUrl = "http://cip:8080/CIP"; //$NON-NLS-1$

	// TODO: set value
	public static final String cipUser = "sample"; //$NON-NLS-1$

	// TODO: set value
	public static final String cipPassword = "sample"; //$NON-NLS-1$

	// TODO: set value of the CIP configured catalog alias to be used
	public static final String cipCatalogAlias = "sample"; //$NON-NLS-1$

	// TODO: set value of the CIP configured view to use
	public static final String cipFieldView = "fields"; //$NON-NLS-1$

	private static final String PREVIEW_REQUEST_PATTERN_WITH_MAXSIZE = "/preview/image/%s/%s?maxsize=%s"; //$NON-NLS-1$

	private static final String PREVIEW_REQUEST_PATTERN = "/preview/image/%s/%s?maxsize=%s"; //$NON-NLS-1$

	private static final String THUMBNAIL_REQUEST_PATTERN_WITH_SIZE = "/preview/thumbnail/%s/%s?maxsize=%s"; //$NON-NLS-1$

	private static final String THUMBNAIL_REQUEST_PATTERN = "/preview/thumbnail/%s/%s"; //$NON-NLS-1$

	private static final String QUICKSEARCH_REQUEST_STRING_PATTERN = "/metadata/search/%s/%s?quicksearchstring=%s"; //$NON-NLS-1$

	private static final String QUERYSEARCH_REQUEST_STRING_PATTERN = "/metadata/search/%s/%s?querystring=%s"; //$NON-NLS-1$

	private static final String GET_CATEGORY_REQUEST_STRING_PATTERN = "/metadata/getcategories/%s/categories"; //$NON-NLS-1$

	private static final String GET_LAYOUT_WITH_VIEW_REQUEST_STRING_PATTERN = "/metadata/getlayout/%s/%s"; //$NON-NLS-1$

	private static final String GET_LAYOUT_REQUEST_STRING_PATTERN = "/metadata/getlayout/%s"; //$NON-NLS-1$

	private static final String SET_FIELDVALUES_REQUEST_STRING_PATTERN = "/metadata/setfieldvalues/%s"; //$NON-NLS-1$

	private static final String GET_CATEGORY_BY_ID_REQUEST_STRING_PATTERN = "/metadata/getcategories/%s/categories?categoryid=%s"; //$NON-NLS-1$

	private static final String CATEGORIES_QUERY_STRING_PATTERN = "Categories is :%s:"; //$NON-NLS-1$

	private static String getEncodedCategoriesQueryString(int categoryId)
	{
		String query = String.format(CATEGORIES_QUERY_STRING_PATTERN, categoryId);
		return URLEncoder.encode(query);
	}

	/**
	 * 
	 * @param catalog
	 *            the catalog-alias, specified in the cip-config file
	 * @param categoryId
	 *            the category-id which subcategories should be displayed
	 * @return a prepared request string which builds the the final part of an
	 *         cip-request
	 */
	public static String getCategoriesByIdRequest(String catalog, int categoryId)
	{
		return String.format(GET_CATEGORY_BY_ID_REQUEST_STRING_PATTERN, catalog, categoryId);
	}

	/**
	 * 
	 * @param catalog
	 *            the catalog-alias, specified in the cip-config file
	 * @param view
	 *            the view which defines the fields that should be shown.
	 *            defined in the cip-config file
	 * @param categoryId
	 *            the category-id which contained records should be displayed
	 * @return a prepared request string which builds the the final part of an
	 *         cip-request
	 */
	public static String getRecordsFromCategoryRequest(String catalog, String view, int categoryId)
	{
		return String.format(QUERYSEARCH_REQUEST_STRING_PATTERN, catalog, view,
				CIPManager.getEncodedCategoriesQueryString(categoryId));
	}

	/**
	 * 
	 * @param catalog
	 *            the catalog-alias, specified in the cip-config file
	 * @return a prepared request string which builds the the final part of an
	 *         cip-request
	 */
	public static String getCategoriesRequest(String catalog)
	{
		return String.format(GET_CATEGORY_REQUEST_STRING_PATTERN, catalog);
	}

	/**
	 * 
	 * @param catalog
	 *            the catalog-alias, specified in the cip-config file
	 * @param itemId
	 *            the id of the record which preview should be displayed
	 * @param maxSize
	 *            the maximum size the preview can be. if maxsize is null the
	 *            full size will be requested
	 * @return a prepared request string which builds the the final part of an
	 *         cip-request
	 */
	public static String getPreviewRequest(String catalog, int itemId, Integer maxSize)
	{
		if (maxSize != null)
		{
			return String.format(PREVIEW_REQUEST_PATTERN_WITH_MAXSIZE, catalog, itemId, maxSize);
		}
		return String.format(PREVIEW_REQUEST_PATTERN, catalog, itemId);
	}

	/**
	 * 
	 * @param catalog
	 *            the catalog-alias, specified in the cip-config file
	 * @param itemId
	 *            the id of the record which thumbnail should be displayed
	 * @param maxSize
	 *            the maximum size the thumbnail can be. if maxsize is null the
	 *            full thumbnail size will be requested
	 * @return a prepared request string which builds the the final part of an
	 *         cip-request
	 */
	public static String getThumbnailRequest(String catalog, int itemId, Integer maxSize)
	{
		if (maxSize != null)
		{
			return String.format(THUMBNAIL_REQUEST_PATTERN_WITH_SIZE, catalog, itemId, maxSize);
		}
		return String.format(THUMBNAIL_REQUEST_PATTERN, catalog, itemId);
	}

	/**
	 * 
	 * @param catalog
	 *            the catalog-alias, specified in the cip-config file
	 * @return a prepared request string which builds the the final part of an
	 *         cip-request
	 */
	public static String getSetFieldValuesRequest(String catalog)
	{
		return String.format(SET_FIELDVALUES_REQUEST_STRING_PATTERN, catalog);
	}

	/**
	 * 
	 * @param catalog
	 *            the catalog-alias, specified in the cip-config file
	 * @param view
	 *            the view which defines the fields that should be shown.
	 *            defined in the cip-config file
	 * @return a prepared request string which builds the the final part of an
	 *         cip-request
	 */
	public static String getLayoutRequest(String catalog, String view)
	{
		if (view != null)
		{
			return String.format(GET_LAYOUT_WITH_VIEW_REQUEST_STRING_PATTERN, catalog, view);
		}
		return String.format(GET_LAYOUT_REQUEST_STRING_PATTERN, catalog);
	}

	/**
	 * 
	 * @param catalog
	 * @param view
	 *            the view which defines the fields that should be shown.
	 *            defined in the cip-config file
	 * @param searchTerm
	 * @return a prepared request string which builds the the final part of an
	 *         cip-request
	 */
	public static String getQuicksearchRequest(String catalog, String view, String searchTerm)
	{
		String encodedSearchTerm = URLEncoder.encode(searchTerm);
		return String.format(QUICKSEARCH_REQUEST_STRING_PATTERN, catalog, view, encodedSearchTerm);
	}

	public static String generateJsonString(int itemId, String field, String value)
	{
		try
		{
			JSONArray array = new JSONArray();
			JSONObject itemObject = new JSONObject();
			itemObject.put("id", itemId); //$NON-NLS-1$
			if (field.equals("Rating") || field.equals("Status")) //$NON-NLS-1$ //$NON-NLS-2$
			{
				itemObject.put(field, Integer.valueOf(value));
			}
			else
			{
				itemObject.put(field, value);
			}
			array.put(itemObject);
			JSONObject object = new JSONObject();
			object.put("items", array); //$NON-NLS-1$
			return object.toString();
		}
		catch (JSONException e)
		{
			Log.e(TAG, e.getMessage(), e);
		}
		return null;
	}
}
