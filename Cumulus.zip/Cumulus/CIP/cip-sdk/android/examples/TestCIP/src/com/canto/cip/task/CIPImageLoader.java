package com.canto.cip.task;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;

import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ImageView;

import com.canto.cip.connection.CIPConnector;
import com.canto.cip.handler.CIPImageResponseHandler;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */
/**
 * starts an asynchronous task which sends an image request to the cip-server an
 * puts the result into an specified container(android.widget.ImageView)
 */
public class CIPImageLoader extends AsyncTask<String, Void, Drawable>
{
	private final static String TAG = CIPImageLoader.class.getSimpleName();

	private ImageView imageView = null;

	public CIPImageLoader(ImageView imageView)
	{
		this.imageView = imageView;
	}

	@Override
	protected Drawable doInBackground(String... params)
	{
		CIPConnector<Drawable> connector = new CIPConnector<Drawable>();
		try
		{
			return connector.sendRequest(params[0], new CIPImageResponseHandler());
		}
		catch (ClientProtocolException e)
		{
			Log.e(TAG, e.getMessage());
		}
		catch (IOException e)
		{
			Log.e(TAG, e.getMessage());
		}
		return null;
	}

	@Override
	protected void onPostExecute(Drawable result)
	{
		if (imageView != null && result != null)
		{
			imageView.setImageDrawable(result);
		}
		super.onPostExecute(result);
	}

}
