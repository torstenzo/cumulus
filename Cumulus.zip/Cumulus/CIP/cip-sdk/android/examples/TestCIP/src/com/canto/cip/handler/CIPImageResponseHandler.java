package com.canto.cip.handler;

import java.io.IOException;
import java.io.InputStream;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.entity.BufferedHttpEntity;

import android.graphics.drawable.Drawable;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */
/**
 * handles the image-response from cip(thumbnail/preview). wrapps the response
 * into an drawable object which can be used android internally
 */
public class CIPImageResponseHandler implements ResponseHandler<Drawable>
{

	public Drawable handleResponse(HttpResponse response) throws ClientProtocolException, IOException
	{
		HttpEntity entity = response.getEntity();
		BufferedHttpEntity bufferedHttpEntity = new BufferedHttpEntity(entity);
		InputStream is = bufferedHttpEntity.getContent();
		return Drawable.createFromStream(is, "src"); //$NON-NLS-1$
	}

}
