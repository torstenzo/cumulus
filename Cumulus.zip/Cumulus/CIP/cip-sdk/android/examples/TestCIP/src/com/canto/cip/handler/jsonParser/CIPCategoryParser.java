package com.canto.cip.handler.jsonParser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.canto.cip.object.structure.CIPCategory;
import com.canto.cip.object.structure.CIPCategoryList;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */
/**
 * parses the json-response from cip.
 */
public class CIPCategoryParser extends AbstractJsonParser<CIPCategoryList>
{
	private static final String TAG = CIPItemParser.class.getSimpleName();

	@Override
	public CIPCategoryList parse(String jsonString)
	{
		CIPCategoryList result = null;
		try
		{
			result = new CIPCategoryList();

			JSONObject jsonObject = new JSONObject(jsonString);
			Integer id = jsonObject.getInt(ID_JSON_IDENTIFIER);
			result.setId(id);

			if (!jsonObject.isNull(SUBCATEGORIES_JSON_IDENTIFIER))
			{
				JSONArray jsonArray = jsonObject.getJSONArray(SUBCATEGORIES_JSON_IDENTIFIER);
				if (jsonArray != null)
				{
					for (int i = 0; i < jsonArray.length(); i++)
					{
						CIPCategory subCategory = new CIPCategory();
						JSONObject currentObject = jsonArray.getJSONObject(i);
						subCategory.setId(currentObject.getInt(ID_JSON_IDENTIFIER));
						subCategory.setName(currentObject.getString(CATEGORY_NAME_JSON_IDENTIFIER));
						result.addSubCategory(subCategory);
					}
				}
			}

			return result;
		}
		catch (JSONException e)
		{
			Log.e(TAG, e.getMessage());
		}
		return null;
	}
}
