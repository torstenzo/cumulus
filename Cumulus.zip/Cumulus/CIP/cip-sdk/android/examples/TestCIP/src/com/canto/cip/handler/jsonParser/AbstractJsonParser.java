package com.canto.cip.handler.jsonParser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;

import android.util.Log;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */
/**
 * basic implementation of an cip-json-responsehandler. all responsehandler
 * which handle cip-json-responses should extends from these base.
 */
public abstract class AbstractJsonParser<T> implements ResponseHandler<T>
{
	private static final String TAG = AbstractJsonParser.class.getSimpleName();

	protected static final String RESULT_ITEMS_JSON_IDENTIFIER = "items"; //$NON-NLS-1$

	protected static final String CAPTION_JSON_IDENTIFIER = "Caption"; //$NON-NLS-1$

	protected static final String WINDOWS_ASSETREFERENCE_JSON_IDENTIFIER = "Asset Reference/Windows"; //$NON-NLS-1$

	protected static final String ZIP_ASSETREFERENCE_JSON_IDENTIFIER = "Asset Reference/ZIP"; //$NON-NLS-1$

	protected static final String CATEGORIES_JSON_IDENTIFIER = "Categories";; //$NON-NLS-1$

	protected static final String ID_JSON_IDENTIFIER = "id"; //$NON-NLS-1$

	protected static final String NAME_JSON_IDENTIFIER = "name"; //$NON-NLS-1$

	protected static final String NOTES_JSON_IDENTIFIER = "Notes"; //$NON-NLS-1$

	protected static final String RATING_JSON_IDENTIFIER = "Rating"; //$NON-NLS-1$

	protected static final String RECORD_NAME_JSON_IDENTIFIER = "Record Name"; //$NON-NLS-1$

	protected static final String FILE_FORMAT_JSON_IDENTIFIER = "File Format"; //$NON-NLS-1$

	protected static final String ASSET_MODIFICATION_DATE_JSON_IDENTIFIER = "Asset Modification Date"; //$NON-NLS-1$

	protected static final String DISPLAYSTRING_JSON_IDENTIFIER = "displaystring"; //$NON-NLS-1$

	protected static final String STATUS_JSON_IDENTIFIER = "Status"; //$NON-NLS-1$

	protected static final String VALUE_JSON_IDENTIFIER = "value"; //$NON-NLS-1$

	protected static final String ASSET_DATA_SIZE_LONG_JSON_IDENTIFIER = "Asset Data Size (Long)"; //$NON-NLS-1$

	protected static final String NULL_VALUE_JSON = "null"; //$NON-NLS-1$

	protected static final String VALUES_JSON_IDENTIFER = "values"; //$NON-NLS-1$

	protected static final String FIELDS_JSON_IDENTIFIER = "fields"; //$NON-NLS-1$

	protected static final String CATEGORY_NAME_JSON_IDENTIFIER = "Category Name"; //$NON-NLS-1$

	protected static final String SUBCATEGORIES_JSON_IDENTIFIER = "subcategories"; //$NON-NLS-1$
	
	protected static final String HAS_SUBCATEGORIES_JSON_IDENTIFIER = "hassubcategories"; //$NON-NLS-1$

	public AbstractJsonParser()
	{
	}

	public abstract T parse(String jsonString);

	public T handleResponse(HttpResponse response) throws ClientProtocolException, IOException
	{
		String jsonString = getJsonString(response.getEntity().getContent());
		return this.parse(jsonString);
	}

	private String getJsonString(InputStream inputStream)
	{
		Writer writer = new StringWriter();
		char[] buffer = new char[1024];
		try
		{
			Reader reader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8")); //$NON-NLS-1$

			int n;

			while ((n = reader.read(buffer)) != -1)
			{
				writer.write(buffer, 0, n);
			}

		}
		catch (UnsupportedEncodingException e)
		{
			Log.e(TAG, e.getMessage());
		}
		catch (IOException e)
		{
			Log.e(TAG, e.getMessage());
		}
		finally
		{
			if (inputStream != null)
			{

				try
				{
					inputStream.close();
				}
				catch (IOException e)
				{
					Log.e(TAG, "failed to close inputstream", e); //$NON-NLS-1$
				}
			}
		}
		return writer.toString();
	}

}
