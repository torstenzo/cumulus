package com.canto.cip.object.structure;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */
/**
 * a mapping class containing the record-fields which are specified in the
 * cip-config file under the point view
 */
public class CIPItem implements Serializable
{
	private static final long serialVersionUID = 4489670771953975540L;

	String caption = null;

	String assetReference_windows = null;

	String assetReference_zip = null;

	List<CIPCategory> categories = new ArrayList<CIPCategory>();

	Integer id = null;

	String notes = ""; //$NON-NLS-1$

	CIPEnum status = null;

	CIPEnum rating = null;

	String recordName = ""; //$NON-NLS-1$

	String fileFormat = ""; //$NON-NLS-1$

	Date assetModificationDate = null;

	CIPEnum dataSize = null;

	public CIPEnum getDataSize()
	{
		return dataSize;
	}

	public void setDataSize(CIPEnum dataSize)
	{
		this.dataSize = dataSize;
	}

	public String getCaption()
	{
		return caption;
	}

	public void setCaption(String caption)
	{
		this.caption = caption;
	}

	public String getAssetReference_windows()
	{
		return assetReference_windows;
	}

	public void setAssetReference_windows(String assetReference_windows)
	{
		this.assetReference_windows = assetReference_windows;
	}

	public String getAssetReference_zip()
	{
		return assetReference_zip;
	}

	public void setAssetReference_zip(String assetReference_zip)
	{
		this.assetReference_zip = assetReference_zip;
	}

	public List<CIPCategory> getCategories()
	{
		return categories;
	}

	public void setCategories(List<CIPCategory> categories)
	{
		this.categories = categories;
	}

	public Integer getId()
	{
		return id;
	}

	public void setId(Integer id)
	{
		this.id = id;
	}

	public String getNotes()
	{
		return notes;
	}

	public void setNotes(String notes)
	{
		this.notes = notes;
	}

	public CIPEnum getStatus()
	{
		return status;
	}

	public void setStatus(CIPEnum status)
	{
		this.status = status;
	}

	public CIPEnum getRating()
	{
		return rating;
	}

	public void setRating(CIPEnum rating)
	{
		this.rating = rating;
	}

	public String getRecordName()
	{
		return recordName;
	}

	public void setRecordName(String recordName)
	{
		this.recordName = recordName;
	}

	public void addCipCategory(CIPCategory category)
	{
		categories.add(category);
	}

	public boolean hasCategories()
	{
		return categories.size() > 0 ? true : false;
	}

	@Override
	public String toString()
	{
		return recordName;
	}

	public String getFileFormat()
	{
		return fileFormat;
	}

	public void setFileFormat(String fileFormat)
	{
		this.fileFormat = fileFormat;
	}

	public Date getAssetModificationDate()
	{
		return assetModificationDate;
	}

	public void setAssetModificationDate(Date assetModificationDate)
	{
		this.assetModificationDate = assetModificationDate;
	}

}
