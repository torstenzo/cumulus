package com.canto.cip.object.structure;

import java.io.Serializable;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */
/**
 * a mapping class which represents fields like datasize and rating
 */
public class CIPEnum implements Serializable
{
	private static final long serialVersionUID = 5765059276551916936L;

	String value = "0"; //$NON-NLS-1$

	String displayString = ""; //$NON-NLS-1$

	public String getValue()
	{
		return value;
	}

	public void setValue(String value)
	{
		this.value = value;
	}

	public String getDisplayString()
	{
		return displayString;
	}

	public void setDisplayString(String displayString)
	{
		this.displayString = displayString;
	}

}
