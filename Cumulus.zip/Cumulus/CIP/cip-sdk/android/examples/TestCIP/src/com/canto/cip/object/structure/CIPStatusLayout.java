package com.canto.cip.object.structure;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */
/**
 * a mapping class, which represents the layout-definition of the field status
 */
public class CIPStatusLayout implements Serializable
{
	private static final long serialVersionUID = 4993121257257298522L;

	private Map<Integer, String> values = new HashMap<Integer, String>();

	public CIPStatusLayout()
	{
	}

	public void putValue(Integer id, String displayString)
	{
		if (!values.containsKey(id))
		{
			values.put(id, displayString);
		}
	}

	public String getDisplayString(Integer id)
	{
		return values.get(id);
	}

	public Integer getId(String displayString)
	{
		for (Integer id : values.keySet())
		{
			if (values.get(id).endsWith(displayString))
			{
				return id;
			}
		}
		return null;
	}

	public Map<Integer, String> getAllValues()
	{
		return values;
	}
}
