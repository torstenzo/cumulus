package com.canto.cip.object.structure;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */
/**
 * a mapping class which contains a list of categories. used to display the
 * available categories via an arrayadapter
 */
public class CIPCategoryList implements Serializable
{
	private static final long serialVersionUID = 2523273962012007501L;

	private Integer id = null;

	private List<CIPCategory> subCategories = new ArrayList<CIPCategory>();

	public Integer getId()
	{
		return id;
	}

	public void setId(Integer id)
	{
		this.id = id;
	}

	public void addSubCategory(CIPCategory cipCategory)
	{
		subCategories.add(cipCategory);
	}

	public List<CIPCategory> getSubCategories()
	{
		return subCategories;
	}

	public boolean hasSubCategories()
	{
		return subCategories.size() > 0 ? true : false;
	}
}
