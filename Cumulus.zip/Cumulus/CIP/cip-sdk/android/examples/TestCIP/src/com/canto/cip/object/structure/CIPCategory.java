package com.canto.cip.object.structure;

import java.io.Serializable;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */
/**
 * a mapping class which contains the category-fields which are specified in the
 * cip-config file under the point view
 */
public class CIPCategory implements Serializable
{
	private static final long serialVersionUID = 4146864282931706297L;

	Integer id = null;

	String name = null;

	public Integer getId()
	{
		return id;
	}

	public void setId(Integer id)
	{
		this.id = id;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	@Override
	public String toString()
	{
		return name;
	}
}
