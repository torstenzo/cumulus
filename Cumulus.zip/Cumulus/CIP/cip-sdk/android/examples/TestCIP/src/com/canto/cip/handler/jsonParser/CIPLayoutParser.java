package com.canto.cip.handler.jsonParser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.canto.cip.object.structure.CIPStatusLayout;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */
/**
 * parses the json-response from cip.
 */
public class CIPLayoutParser extends AbstractJsonParser<CIPStatusLayout>
{
	private static final String TAG = CIPLayoutParser.class.getSimpleName();

	@Override
	public CIPStatusLayout parse(String jsonString)
	{
		CIPStatusLayout result = null;

		try
		{
			JSONObject jsonObect = new JSONObject(jsonString);

			JSONArray items = jsonObect.getJSONArray(FIELDS_JSON_IDENTIFIER);
			if (items != null)
			{
				for (int i = 0; i < items.length(); i++)
				{
					JSONObject itemJsonObject = items.getJSONObject(i);
					String name = itemJsonObject.getString(NAME_JSON_IDENTIFIER);
					if (name.equals(STATUS_JSON_IDENTIFIER))
					{
						result = new CIPStatusLayout();
						JSONArray values = itemJsonObject.getJSONArray(VALUES_JSON_IDENTIFER);
						for (int j = 0; j < values.length(); j++)
						{
							JSONObject obj = values.getJSONObject(j);
							result.putValue(obj.getInt(ID_JSON_IDENTIFIER),
									obj.getString(DISPLAYSTRING_JSON_IDENTIFIER));
						}
					}
				}

			}
		}
		catch (JSONException e)
		{
			Log.e(TAG, e.getMessage(), e);
		}
		return result;
	}
}
