package com.canto.cip.connection;

import java.io.IOException;

import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import com.canto.cip.handler.CIPUpdateResponseHandler;
import com.canto.cip.manager.CIPManager;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */
/**
 * sends post-requests to an configured server
 */
public class CIPConnector<T>
{
	private DefaultHttpClient defaultHttpClient = null;

	public CIPConnector()
	{
		defaultHttpClient = new DefaultHttpClient();
		CredentialsProvider provider = defaultHttpClient.getCredentialsProvider();
		setCredentials(provider);
	}

	public T sendRequest(String request, ResponseHandler<T> responseHandler) throws ClientProtocolException,
			IOException
	{
		request = CIPManager.cipBaseUrl + request;
		HttpPost postRequest = new HttpPost(request);
		postRequest.setHeader("Content-Type", "	application/json"); //$NON-NLS-1$ //$NON-NLS-2$
		return defaultHttpClient.execute(postRequest, responseHandler);
	}

	public Integer sendRequest(String request, String jsonString) throws ClientProtocolException, IOException
	{
		request = CIPManager.cipBaseUrl + request;
		HttpPost postRequest = new HttpPost(request);
		postRequest.setHeader("Content-Type", "	application/json"); //$NON-NLS-1$ //$NON-NLS-2$
		postRequest.setEntity(new StringEntity(jsonString));
		return defaultHttpClient.execute(postRequest, new CIPUpdateResponseHandler());
	}

	private void setCredentials(CredentialsProvider provider)
	{
		AuthScope authscope = new AuthScope(AuthScope.ANY_HOST, AuthScope.ANY_PORT);
		UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(CIPManager.cipUser,
				CIPManager.cipPassword);
		provider.setCredentials(authscope, credentials);
	}
}
