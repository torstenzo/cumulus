package com.canto.cip.handler;

import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */
public class CIPUpdateResponseHandler implements ResponseHandler<Integer>
{
	public Integer handleResponse(HttpResponse response) throws ClientProtocolException, IOException
	{
		return response.getStatusLine().getStatusCode();
	}

}
