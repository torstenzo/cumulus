package com.canto.cip.activities;

import java.io.IOException;

import org.apache.http.client.ClientProtocolException;

import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.canto.cip.R;
import com.canto.cip.connection.CIPConnector;
import com.canto.cip.handler.jsonParser.CIPCategoryParser;
import com.canto.cip.manager.CIPManager;
import com.canto.cip.object.structure.CIPCategory;
import com.canto.cip.object.structure.CIPCategoryList;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */

public class CIPCategoriesActivity extends ListActivity
{
	private static final String TAG = CIPCategoriesActivity.class.getSimpleName();

	public static final String CATEGORY_ITEM_IDENTIFIER = "com.canto.cip.categoryitem"; //$NON-NLS-1$

	public static final String CATEGORY_ID_IDENTIFIER = "com.canto.cip.categoryid"; //$NON-NLS-1$

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.cip_categories);

		CIPCategoryList categoryList = null;

		Intent intent = getIntent();
		if (intent.hasExtra(CATEGORY_ITEM_IDENTIFIER))
		{
			CIPCategory cipCategory = (CIPCategory) intent.getSerializableExtra(CATEGORY_ITEM_IDENTIFIER);
			categoryList = goToSubCategory(cipCategory);
		}
		else
		{
			categoryList = getBaseCategory();
		}

		if (categoryList != null)
		{
			if (categoryList.hasSubCategories())
			{
				this.getListView().setAdapter(
						new ArrayAdapter<CIPCategory>(this, android.R.layout.simple_list_item_1, categoryList
								.getSubCategories()));
			}
			else
			{
				Intent thumbnailIntent = new Intent().setClass(getApplicationContext(), CIPThumbnailActivity.class);
				thumbnailIntent.putExtra(CATEGORY_ID_IDENTIFIER, categoryList.getId());
				startActivity(thumbnailIntent);
				this.finish();
			}
		}
		Log.i(TAG, "no categories found. pleas check connection"); //$NON-NLS-1$

	}

	private CIPCategoryList goToSubCategory(CIPCategory cipCategory)
	{
		CIPConnector<CIPCategoryList> connector = new CIPConnector<CIPCategoryList>();
		try
		{
			String request = CIPManager.getCategoriesByIdRequest(CIPManager.cipCatalogAlias, cipCategory.getId());
			return connector.sendRequest(request, new CIPCategoryParser());

		}
		catch (ClientProtocolException e)
		{
			Log.e(TAG, e.getMessage());
		}
		catch (IOException e)
		{
			Log.e(TAG, e.getMessage());
		}
		return null;
	}

	private CIPCategoryList getBaseCategory()
	{
		CIPConnector<CIPCategoryList> connector = new CIPConnector<CIPCategoryList>();
		try
		{
			String request = CIPManager.getCategoriesRequest(CIPManager.cipCatalogAlias);
			return connector.sendRequest(request, new CIPCategoryParser());
		}
		catch (ClientProtocolException e)
		{
			Log.e(TAG, e.getMessage());
		}
		catch (IOException e)
		{
			Log.e(TAG, e.getMessage());
		}
		return null;
	}

	@Override
	protected void onListItemClick(ListView l, View v, int position, long id)
	{
		super.onListItemClick(l, v, position, id);
		CIPCategory cipCategory = (CIPCategory) l.getAdapter().getItem(position);
		Intent intent = new Intent().setClass(getApplicationContext(), CIPCategoriesActivity.class);
		intent.putExtra(CATEGORY_ITEM_IDENTIFIER, cipCategory);
		startActivity(intent);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		getMenuInflater().inflate(R.menu.cip_searchmenu, menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch (item.getItemId())
		{
		case R.id.search_menu_id:
			Intent intent = new Intent().setClass(getApplicationContext(), CIPQuicksearchActivity.class);
			startActivity(intent);
			break;

		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

}