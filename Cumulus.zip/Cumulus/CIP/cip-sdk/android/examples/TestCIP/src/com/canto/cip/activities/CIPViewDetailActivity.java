package com.canto.cip.activities;

import java.text.SimpleDateFormat;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.canto.cip.R;
import com.canto.cip.manager.CIPManager;
import com.canto.cip.object.structure.CIPItem;
import com.canto.cip.task.CIPImageLoader;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */

public class CIPViewDetailActivity extends Activity
{

	private CIPItem cipItem = null;

	public static final String ITEM_IDENTIFIER = "com.canto.cip.item"; //$NON-NLS-1$

	public static final String FIELD_IDENTIFIER = "com.canto.cip.fieldidentifier"; //$NON-NLS-1$

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.cip_viewdetail);
		Intent intent = getIntent();
		if (intent.hasExtra(ITEM_IDENTIFIER))
		{
			cipItem = (CIPItem) intent.getSerializableExtra(ITEM_IDENTIFIER);
			fillLayoutWithContent();
		}
	}

	private void fillLayoutWithContent()
	{
		ImageView imageView = (ImageView) findViewById(R.id.cip_viewdetail_headerthumbnail);

		// load image asynchronous
		CIPImageLoader loader = new CIPImageLoader(imageView);
		String request = CIPManager.getThumbnailRequest(CIPManager.cipCatalogAlias, cipItem.getId(), 70);
		loader.execute(request);

		// view header
		TextView itemName = (TextView) findViewById(R.id.cip_viewdetail_item_name);
		itemName.setText(cipItem.getRecordName());
		TextView itemType = (TextView) findViewById(R.id.cip_viewdetail_item_type);
		itemType.setText(cipItem.getFileFormat());

		// record name
		TextView recordNameView = (TextView) findViewById(R.id.cip_record_name_content_textview);
		recordNameView.setText(cipItem.getRecordName());

		// file format
		TextView fileFormatView = (TextView) findViewById(R.id.cip_file_format_content_textview);
		fileFormatView.setText(cipItem.getFileFormat());

		// rating
		RatingBar ratingBar = (RatingBar) findViewById(R.id.cip_ratingbar);
		float rating = 0f;
		if (cipItem.getRating() != null)
		{
			rating = Float.valueOf(cipItem.getRating().getValue());
		}
		ratingBar.setRating(rating);

		// notes
		TextView notesView = (TextView) findViewById(R.id.cip_notes_content_textview);
		notesView.setText(cipItem.getNotes());

		// status
		TextView statusView = (TextView) findViewById(R.id.cip_status_content_textview);
		String status = null;
		if (cipItem.getStatus() != null)
		{
			status = cipItem.getStatus().getDisplayString();
			
		}
		statusView.setText(status);

		// datasize
		TextView dataSizeView = (TextView) findViewById(R.id.cip_datasize_content_textview);
		String dataSize = null;
		if (cipItem.getDataSize() != null)
		{
			dataSize = cipItem.getDataSize().getDisplayString();
		}
		dataSizeView.setText(dataSize);
		
		// assetmodificationdate
		TextView assetModificationDateView = (TextView) findViewById(R.id.cip_assetmodificationdate_content_textview);
		String formatedDate = null;
		if (cipItem.getAssetModificationDate() != null)
		{
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //$NON-NLS-1$
			formatedDate = simpleDateFormat.format(cipItem.getAssetModificationDate());
			
		}
		assetModificationDateView.setText(formatedDate);
	}

	public void cipOnClickHandler(View view)
	{
		Intent intent = new Intent().setClass(getApplicationContext(), CIPMetadataEditActivity.class);
		intent.putExtra(ITEM_IDENTIFIER, cipItem);
		switch (view.getId())
		{
		case R.id.cip_rating_row:
			intent.putExtra(FIELD_IDENTIFIER, R.id.cip_rating_row);
			break;
		case R.id.cip_notes_row:
			intent.putExtra(FIELD_IDENTIFIER, R.id.cip_notes_row);
			break;
		case R.id.cip_status_row:
			intent.putExtra(FIELD_IDENTIFIER, R.id.cip_status_row);
			break;
		default:
			break;
		}
		startActivityForResult(intent, 1);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);
		if (data != null && data.hasExtra(ITEM_IDENTIFIER))
		{
			cipItem = (CIPItem) data.getSerializableExtra(ITEM_IDENTIFIER);
			fillLayoutWithContent();
		}
	}

}
