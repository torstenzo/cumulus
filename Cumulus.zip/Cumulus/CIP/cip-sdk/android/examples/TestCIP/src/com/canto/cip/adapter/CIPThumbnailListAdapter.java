package com.canto.cip.adapter;

import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.canto.cip.R;
import com.canto.cip.activities.CIPViewDetailActivity;
import com.canto.cip.manager.CIPManager;
import com.canto.cip.object.structure.CIPItem;
import com.canto.cip.task.CIPImageLoader;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */
public class CIPThumbnailListAdapter extends ArrayAdapter<CIPItem>
{
	public CIPThumbnailListAdapter(Context context, int textViewResourceId, List<CIPItem> objects)
	{
		super(context, textViewResourceId, objects);
	}

	@Override
	public View getView(int position, View convertView, final ViewGroup parent)
	{
		final CIPItem cipItem = getItem(position);

		ViewHolder holder = null;

		if (convertView == null)
		{
			convertView = LayoutInflater.from(getContext()).inflate(R.layout.cip_thumbnaill_list, parent, false);
			holder = new ViewHolder();
			holder.imageThumb = (ImageView) convertView.findViewById(R.id.cip_thumbnail_preview);
			holder.imageButton = (ImageView) convertView.findViewById(R.id.cip_show_detail);
			holder.text = (TextView) convertView.findViewById(R.id.cip_record_name);
			holder.type = (TextView) convertView.findViewById(R.id.cip_record_type);

			convertView.setTag(holder);
		}
		else
		{
			holder = (ViewHolder) convertView.getTag();
		}

		CIPImageLoader loader = new CIPImageLoader(holder.imageThumb);
		String request = CIPManager.getThumbnailRequest(CIPManager.cipCatalogAlias, cipItem.getId(), 70);
		loader.execute(request);

		holder.text.setText(cipItem.getRecordName());
		holder.type.setText(cipItem.getFileFormat());

		holder.imageButton.setOnClickListener(new OnClickListener()
		{
			public void onClick(View v)
			{
				Intent intent = new Intent().setClass(parent.getContext(), CIPViewDetailActivity.class);
				intent.putExtra(CIPViewDetailActivity.ITEM_IDENTIFIER, cipItem);
				getContext().startActivity(intent);
			}
		});

		return convertView;
	}

	static class ViewHolder
	{
		TextView text;

		TextView type;

		ImageView imageButton;

		ImageView imageThumb;
	}
}
