package com.canto.cip.activities;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import com.canto.cip.R;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */

public class CIPQuicksearchActivity extends Activity
{

	public static final String QUICKSEARCH_STRING_IDENTIFIER = "com.canto.cip.quicksearchstring"; //$NON-NLS-1$

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.cip_quicksearch);

		final EditText editTextView = (EditText) findViewById(R.id.cip_quicksearch_content);
		Button submitButton = (Button) findViewById(R.id.cip_submit_button);
		submitButton.setOnClickListener(new OnClickListener()
		{

			public void onClick(View v)
			{
				Intent intent = new Intent().setClass(getApplicationContext(), CIPThumbnailActivity.class);
				intent.putExtra(QUICKSEARCH_STRING_IDENTIFIER, editTextView.getEditableText().toString());
				startActivity(intent);
			}
		});

	}
}
