package com.canto.cip.object.structure;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */
/**
 * a mapping class for the search response. containing the search result count
 * and a list of items which match the searchterm
 */
public class CipSearchResult implements Serializable
{
	private static final long serialVersionUID = -1044791085595733940L;

	Integer totalCount = null;

	List<CIPItem> cipItems = new ArrayList<CIPItem>();

	public Integer getTotalCount()
	{
		return totalCount;
	}

	public void setTotalCount(Integer totalCount)
	{
		this.totalCount = totalCount;
	}

	public List<CIPItem> getCipItems()
	{
		return cipItems;
	}

	public void addResultId(CIPItem item)
	{
		cipItems.add(item);
	}

}
