package com.canto.cip.activities;

import java.io.IOException;

import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RatingBar;

import com.canto.cip.R;
import com.canto.cip.connection.CIPConnector;
import com.canto.cip.handler.jsonParser.CIPLayoutParser;
import com.canto.cip.manager.CIPManager;
import com.canto.cip.object.structure.CIPItem;
import com.canto.cip.object.structure.CIPStatusLayout;

/**
 * CANTO INTEGRATION PLATFORM Copyright 2011 Canto GmbH All Rights Reserved.
 * 
 * NOTICE: Canto GmbH permits you to use, modify, and distribute this file in
 * accordance with the terms of the license agreement accompanying it.
 */

public class CIPMetadataEditActivity extends Activity implements OnClickListener
{
	private static final String TAG = CIPMetadataEditActivity.class.getSimpleName();

	private EditText editText = null;

	private RatingBar ratingBar = null;

	private RadioGroup radioGroup = null;

	private int id = -1;

	private CIPItem cipItem = null;

	private CIPStatusLayout statusLayout = null;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.cip_metadataedit);

		Intent intent = getIntent();
		if (intent.hasExtra(CIPViewDetailActivity.FIELD_IDENTIFIER)
				&& intent.hasExtra(CIPViewDetailActivity.ITEM_IDENTIFIER))
		{
			cipItem = (CIPItem) intent.getSerializableExtra(CIPViewDetailActivity.ITEM_IDENTIFIER);
			id = intent.getIntExtra(CIPViewDetailActivity.FIELD_IDENTIFIER, -1);

			editText = (EditText) findViewById(R.id.cip_edit_text);
			ratingBar = (RatingBar) findViewById(R.id.cip_edit_ratingbar);
			radioGroup = (RadioGroup) findViewById(R.id.cip_radio_group);
			switch (id)
			{
			case R.id.cip_rating_row:
				ratingBar.setRating(Float.valueOf(cipItem.getRating().getValue()));
				ratingBar.setVisibility(View.VISIBLE);
				break;
			case R.id.cip_notes_row:
				editText.setText(cipItem.getNotes());
				editText.setVisibility(View.VISIBLE);
				break;
			case R.id.cip_status_row:
				fillRadioGroup();
				break;
			default:
				break;
			}

			Button saveButton = (Button) findViewById(R.id.cip_save_btn);
			saveButton.setOnClickListener(this);
		}
	}

	private void fillRadioGroup()
	{
		if (radioGroup != null)
		{
			CIPConnector<CIPStatusLayout> connector = new CIPConnector<CIPStatusLayout>();
			String request = CIPManager.getLayoutRequest(CIPManager.cipCatalogAlias, CIPManager.cipFieldView);
			try
			{
				statusLayout = connector.sendRequest(request, new CIPLayoutParser());
				for (Integer key : statusLayout.getAllValues().keySet())
				{
					RadioButton radioButton = new RadioButton(getApplicationContext());
					radioButton.setText(statusLayout.getDisplayString(key));
					radioButton.setId(key);
					if (key.equals(Integer.valueOf(cipItem.getStatus().getValue())))
					{
						radioButton.setChecked(true);
					}
					radioGroup.addView(radioButton);
				}
				radioGroup.setVisibility(View.VISIBLE);
			}
			catch (ClientProtocolException e)
			{
				Log.e(TAG, e.getMessage(), e);
			}
			catch (IOException e)
			{
				Log.e(TAG, e.getMessage(), e);
			}
		}
	}

	public void onClick(View v)
	{
		switch (id)
		{
		case R.id.cip_rating_row:
			String ratingValue = String.valueOf(((int) ratingBar.getRating()));
			String rating = CIPManager.generateJsonString(cipItem.getId(), "Rating", //$NON-NLS-1$
					String.valueOf(((int) ratingBar.getRating())));
			cipItem.getRating().setValue(ratingValue);
			sendRequest(rating);
			break;
		case R.id.cip_notes_row:
			String currentNotes = editText.getEditableText().toString();
			String notes = CIPManager.generateJsonString(cipItem.getId(), "Notes", editText.getEditableText() //$NON-NLS-1$
					.toString());
			cipItem.setNotes(currentNotes);
			sendRequest(notes);
			break;
		case R.id.cip_status_row:
			int selectedId = radioGroup.getCheckedRadioButtonId();
			String status = CIPManager.generateJsonString(cipItem.getId(), "Status", String.valueOf(selectedId)); //$NON-NLS-1$
			cipItem.getStatus().setDisplayString(statusLayout.getDisplayString(selectedId));
			cipItem.getStatus().setValue(String.valueOf(selectedId));
			sendRequest(status);
			break;
		default:
			break;
		}
	}

	private void sendRequest(String jsonString)
	{
		CIPConnector<Integer> connector = new CIPConnector<Integer>();
		String request = CIPManager.getSetFieldValuesRequest(CIPManager.cipCatalogAlias);
		try
		{
			Integer httpStatus = connector.sendRequest(request, jsonString);
			if (httpStatus.equals(HttpStatus.SC_OK))
			{
				Intent data = new Intent();
				data.putExtra(CIPViewDetailActivity.ITEM_IDENTIFIER, cipItem);
				setResult(1, data);
				this.finish();
			}
		}
		catch (ClientProtocolException e)
		{
			Log.d(TAG, e.getMessage(), e);
		}
		catch (IOException e)
		{
			Log.d(TAG, e.getMessage(), e);
		}
	}
}
