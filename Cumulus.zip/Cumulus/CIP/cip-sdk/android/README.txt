                               README

                     Canto Integration Platform
 
                        Android Sample Code
                      Android Example Project

The Canto Integration Platform consists of a server components and SDKs for
developing client-side code. The server component is a web application that
is deployed into a web application container (e.g. Apache Tomcat).
The client SDK consists of libraries, sample code and example projects for
different programming environments:

- Microsoft .Net (C#)
- Adobe Flash/ActionScript
- PHP
- Java
- JavaScript
- Apple iOS (Objective-C)
- Google Android (Android-Java)

================================================================================
    License Conditions
================================================================================
Permission is hereby granted, free of charge, to any person obtaining a copy of
this SDK, to deal in the Software without restriction, including without
limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom
the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
================================================================================
    System Requirements
================================================================================
Android 2.2 (API version 8) or later
Android SDK

================================================================================
    Contents
================================================================================
This SDK consists of the following folders:

examples
   Example projects including source code

================================================================================
    Getting Started
================================================================================

You can learn how to write CIP client side code by opening the example project.
It contains all code necessary for building an Android app.
To test the example project you need to adjust some strings in source code:
In the package "com.canto.cip.manager" edit the file "CIPManager.java" and look
for the "TODO" comments. Especially the address of the CIP server needs to be
adapted to your environment.

================================================================================
    KNOWN PROBLEMS
================================================================================
- R.java is not generated for Android CIP example and it drive to compilation error

    Go to Project and hit Clean. This should, among others, regenerate your R.java file.
    Apparently that problem can be related to incorrect target build settings too.
    The older Android SDK version e.g. Android 2.1 (SDK v7) is not compatible
    with the layout XML used by required Android 2.2 (SDK v8) elements.

Copyright (c) 2012, Canto GmbH