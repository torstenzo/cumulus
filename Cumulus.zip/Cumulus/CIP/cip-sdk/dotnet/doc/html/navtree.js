var NAVTREE =
[
  [ "C# client library", "index.html", [
    [ "Class List", "annotated.html", [
      [ "Canto.Cip.Lib.CIPManager", "class_canto_1_1_cip_1_1_lib_1_1_c_i_p_manager.html", null ],
      [ "Canto.Cip.Lib.CIPSession", "class_canto_1_1_cip_1_1_lib_1_1_c_i_p_session.html", null ],
      [ "Canto.Cip.Lib.CollectionListResult", "class_canto_1_1_cip_1_1_lib_1_1_collection_list_result.html", null ],
      [ "Canto.Cip.Lib.CollectionResult", "class_canto_1_1_cip_1_1_lib_1_1_collection_result.html", null ],
      [ "Canto.Cip.Lib.DamCollection", "class_canto_1_1_cip_1_1_lib_1_1_dam_collection.html", null ],
      [ "Canto.Cip.Lib.DamException", "class_canto_1_1_cip_1_1_lib_1_1_dam_exception.html", null ],
      [ "Canto.Cip.Lib.DamItem", "class_canto_1_1_cip_1_1_lib_1_1_dam_item.html", null ],
      [ "Canto.Cip.Lib.Entities.Coordinates", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_coordinates.html", null ],
      [ "Canto.Cip.Lib.Entities.DamAudioValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_audio_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamBinaryValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_binary_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamCategoriesList", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_categories_list.html", null ],
      [ "Canto.Cip.Lib.Entities.DamCategoryValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_category_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamCollectionCatalog", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_collection_catalog.html", null ],
      [ "Canto.Cip.Lib.Entities.DamCollectionRecipient", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_collection_recipient.html", null ],
      [ "Canto.Cip.Lib.Entities.DamDataSizeValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_data_size_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamDateOnlyValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_date_only_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamItemVersionInformation", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_item_version_information.html", null ],
      [ "Canto.Cip.Lib.Entities.DamKeyValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_key_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamLabelValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_label_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamLayoutField", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_layout_field.html", null ],
      [ "Canto.Cip.Lib.Entities.DamOption", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_option.html", null ],
      [ "Canto.Cip.Lib.Entities.DamOptionQuery", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_option_query.html", null ],
      [ "Canto.Cip.Lib.Entities.DamOptionQueryPlaceholder", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_option_query_placeholder.html", null ],
      [ "Canto.Cip.Lib.Entities.DamPictureValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_picture_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamRatingValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_rating_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamStringListValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_string_list_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamTimeOnlyValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_time_only_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamUserUIDValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_user_u_i_d_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamVersion", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_version.html", null ],
      [ "Canto.Cip.Lib.Entities.DamViewField", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_view_field.html", null ],
      [ "Canto.Cip.Lib.Entities.DownloadItem", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_download_item.html", null ],
      [ "Canto.Cip.Lib.Entities.FileItem", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_file_item.html", null ],
      [ "Canto.Cip.Lib.Entities.FilterListState", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_filter_list_state.html", null ],
      [ "Canto.Cip.Lib.Entities.FilterOptionState", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_filter_option_state.html", null ],
      [ "Canto.Cip.Lib.Entities.FilterState", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_filter_state.html", null ],
      [ "Canto.Cip.Lib.Entities.Listing", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_listing.html", null ],
      [ "Canto.Cip.Lib.Entities.Point2D", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_point2_d.html", null ],
      [ "Canto.Cip.Lib.Entities.Role", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_role.html", null ],
      [ "Canto.Cip.Lib.Entities.ServiceVersion", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_service_version.html", null ],
      [ "Canto.Cip.Lib.Entities.SortFieldDescriptor", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_sort_field_descriptor.html", null ],
      [ "Canto.Cip.Lib.Entities.UploadItem", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_upload_item.html", null ],
      [ "Canto.Cip.Lib.Entities.User", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_user.html", null ],
      [ "Canto.Cip.Lib.Entities.UserComment", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_user_comment.html", null ],
      [ "Canto.Cip.Lib.Entities.UserCommentsThread", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_user_comments_thread.html", null ],
      [ "Canto.Cip.Lib.Entities.VersionInformation", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_version_information.html", null ],
      [ "Canto.Cip.Lib.Entities.WorkflowActivityInformation", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_workflow_activity_information.html", null ],
      [ "Canto.Cip.Lib.Entities.WorkflowInformation", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_workflow_information.html", null ],
      [ "Canto.Cip.Lib.Entities.WorkflowItemInformation", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_workflow_item_information.html", null ],
      [ "Canto.Cip.Lib.Entities.WorkflowStateInformation", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_workflow_state_information.html", null ],
      [ "Canto.Cip.Lib.QueryResult", "class_canto_1_1_cip_1_1_lib_1_1_query_result.html", null ]
    ] ],
    [ "Class Index", "classes.html", null ],
    [ "Class Hierarchy", "hierarchy.html", [
      [ "Canto.Cip.Lib.CIPManager", "class_canto_1_1_cip_1_1_lib_1_1_c_i_p_manager.html", null ],
      [ "Canto.Cip.Lib.CIPSession", "class_canto_1_1_cip_1_1_lib_1_1_c_i_p_session.html", null ],
      [ "Canto.Cip.Lib.CollectionListResult", "class_canto_1_1_cip_1_1_lib_1_1_collection_list_result.html", null ],
      [ "Canto.Cip.Lib.CollectionResult", "class_canto_1_1_cip_1_1_lib_1_1_collection_result.html", null ],
      [ "Canto.Cip.Lib.DamCollection", "class_canto_1_1_cip_1_1_lib_1_1_dam_collection.html", null ],
      [ "Canto.Cip.Lib.DamItem", "class_canto_1_1_cip_1_1_lib_1_1_dam_item.html", null ],
      [ "Canto.Cip.Lib.Entities.Coordinates", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_coordinates.html", null ],
      [ "Canto.Cip.Lib.Entities.DamAudioValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_audio_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamBinaryValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_binary_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamCategoriesList", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_categories_list.html", null ],
      [ "Canto.Cip.Lib.Entities.DamCategoryValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_category_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamCollectionCatalog", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_collection_catalog.html", null ],
      [ "Canto.Cip.Lib.Entities.DamCollectionRecipient", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_collection_recipient.html", null ],
      [ "Canto.Cip.Lib.Entities.DamDataSizeValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_data_size_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamDateOnlyValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_date_only_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamItemVersionInformation", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_item_version_information.html", null ],
      [ "Canto.Cip.Lib.Entities.DamKeyValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_key_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamLabelValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_label_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamLayoutField", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_layout_field.html", null ],
      [ "Canto.Cip.Lib.Entities.DamOption", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_option.html", [
        [ "Canto.Cip.Lib.Entities.DamOptionQuery", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_option_query.html", null ]
      ] ],
      [ "Canto.Cip.Lib.Entities.DamOptionQueryPlaceholder", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_option_query_placeholder.html", null ],
      [ "Canto.Cip.Lib.Entities.DamPictureValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_picture_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamRatingValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_rating_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamStringListValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_string_list_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamTimeOnlyValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_time_only_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamUserUIDValue", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_user_u_i_d_value.html", null ],
      [ "Canto.Cip.Lib.Entities.DamVersion", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_version.html", null ],
      [ "Canto.Cip.Lib.Entities.DamViewField", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_dam_view_field.html", null ],
      [ "Canto.Cip.Lib.Entities.DownloadItem", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_download_item.html", null ],
      [ "Canto.Cip.Lib.Entities.FileItem", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_file_item.html", null ],
      [ "Canto.Cip.Lib.Entities.FilterListState", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_filter_list_state.html", null ],
      [ "Canto.Cip.Lib.Entities.FilterOptionState", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_filter_option_state.html", null ],
      [ "Canto.Cip.Lib.Entities.FilterState", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_filter_state.html", null ],
      [ "Canto.Cip.Lib.Entities.Listing", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_listing.html", null ],
      [ "Canto.Cip.Lib.Entities.Point2D", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_point2_d.html", null ],
      [ "Canto.Cip.Lib.Entities.Role", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_role.html", null ],
      [ "Canto.Cip.Lib.Entities.ServiceVersion", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_service_version.html", null ],
      [ "Canto.Cip.Lib.Entities.SortFieldDescriptor", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_sort_field_descriptor.html", null ],
      [ "Canto.Cip.Lib.Entities.UploadItem", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_upload_item.html", null ],
      [ "Canto.Cip.Lib.Entities.User", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_user.html", null ],
      [ "Canto.Cip.Lib.Entities.UserComment", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_user_comment.html", null ],
      [ "Canto.Cip.Lib.Entities.UserCommentsThread", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_user_comments_thread.html", null ],
      [ "Canto.Cip.Lib.Entities.VersionInformation", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_version_information.html", null ],
      [ "Canto.Cip.Lib.Entities.WorkflowActivityInformation", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_workflow_activity_information.html", null ],
      [ "Canto.Cip.Lib.Entities.WorkflowInformation", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_workflow_information.html", null ],
      [ "Canto.Cip.Lib.Entities.WorkflowItemInformation", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_workflow_item_information.html", null ],
      [ "Canto.Cip.Lib.Entities.WorkflowStateInformation", "class_canto_1_1_cip_1_1_lib_1_1_entities_1_1_workflow_state_information.html", null ],
      [ "Canto.Cip.Lib.QueryResult", "class_canto_1_1_cip_1_1_lib_1_1_query_result.html", null ],
      [ "Exception", null, [
        [ "Canto.Cip.Lib.DamException", "class_canto_1_1_cip_1_1_lib_1_1_dam_exception.html", null ]
      ] ]
    ] ],
    [ "Class Members", "functions.html", null ],
    [ "Packages", "namespaces.html", [
      [ "Canto", "namespace_canto.html", null ],
      [ "Canto::Cip", "namespace_canto_1_1_cip.html", null ],
      [ "Canto.Cip.Lib", "namespace_canto_1_1_cip_1_1_lib.html", null ],
      [ "Canto.Cip.Lib.Constants", "namespace_canto_1_1_cip_1_1_lib_1_1_constants.html", null ],
      [ "Canto.Cip.Lib.Entities", "namespace_canto_1_1_cip_1_1_lib_1_1_entities.html", null ],
      [ "Canto.Cip.Lib.Utils", "namespace_canto_1_1_cip_1_1_lib_1_1_utils.html", null ]
    ] ],
    [ "Package Functions", "namespacemembers.html", null ],
    [ "File List", "files.html", [
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/CIPManager.cs", "_c_i_p_manager_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/CIPSession.cs", "_c_i_p_session_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/DamException.cs", "_dam_exception_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/DamItem.cs", "_dam_item_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/Node.cs", "_node_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/QueryResult.cs", "_query_result_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/Utilities.cs", "_utilities_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/constants/CacheControl.cs", "_cache_control_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/constants/CollectionType.cs", "_collection_type_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/constants/Combine.cs", "_combine_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/constants/CommentType.cs", "_comment_type_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/constants/DamFieldType.cs", "_dam_field_type_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/constants/FileType.cs", "_file_type_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/constants/IfCategoryExists.cs", "_if_category_exists_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/constants/IfExists.cs", "_if_exists_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/constants/JsonParameters.cs", "_json_parameters_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/constants/KeyValueAttribute.cs", "_key_value_attribute_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/constants/LinkPermission.cs", "_link_permission_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/constants/LocationType.cs", "_location_type_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/constants/Options.cs", "_options_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/constants/Parameters.cs", "_parameters_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/constants/PictureViewSize.cs", "_picture_view_size_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/constants/PredefinedFields.cs", "_predefined_fields_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/constants/Relation.cs", "_relation_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/constants/SortDirection.cs", "_sort_direction_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/constants/UseCache.cs", "_use_cache_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/constants/UserFindRequirements.cs", "_user_find_requirements_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/constants/VirtualFields.cs", "_virtual_fields_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/CollectionListResult.cs", "_collection_list_result_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/CollectionResult.cs", "_collection_result_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/Coordinates.cs", "_coordinates_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamAudioValue.cs", "_dam_audio_value_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamBinaryValue.cs", "_dam_binary_value_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamCategoriesList.cs", "_dam_categories_list_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamCategoryValue.cs", "_dam_category_value_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamCollection.cs", "_dam_collection_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamCollectionCatalog.cs", "_dam_collection_catalog_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamCollectionRecipient.cs", "_dam_collection_recipient_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamDataSizeValue.cs", "_dam_data_size_value_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamDateOnlyValue.cs", "_dam_date_only_value_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamItemVersionInformation.cs", "_dam_item_version_information_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamKeyValue.cs", "_dam_key_value_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamLabelValue.cs", "_dam_label_value_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamLayoutField.cs", "_dam_layout_field_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamOption.cs", "_dam_option_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamOptionQuery.cs", "_dam_option_query_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamOptionQueryPlaceholder.cs", "_dam_option_query_placeholder_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamPictureValue.cs", "_dam_picture_value_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamRatingValue.cs", "_dam_rating_value_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamStringListValue.cs", "_dam_string_list_value_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamTimeOnlyValue.cs", "_dam_time_only_value_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamUserUIDValue.cs", "_dam_user_u_i_d_value_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamVersion.cs", "_dam_version_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DamViewField.cs", "_dam_view_field_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/DownloadItem.cs", "_download_item_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/FileItem.cs", "_file_item_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/FilterListState.cs", "_filter_list_state_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/FilterOptionState.cs", "_filter_option_state_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/FilterState.cs", "_filter_state_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/Listing.cs", "_listing_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/Point2D.cs", "_point2_d_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/Role.cs", "_role_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/ServiceVersion.cs", "_service_version_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/SortFieldDescriptor.cs", "_sort_field_descriptor_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/UploadItem.cs", "_upload_item_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/User.cs", "_user_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/UserComment.cs", "_user_comment_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/UserCommentsThread.cs", "_user_comments_thread_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/VersionInformation.cs", "_version_information_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/WorkflowActivityInformation.cs", "_workflow_activity_information_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/WorkflowInformation.cs", "_workflow_information_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/WorkflowItemInformation.cs", "_workflow_item_information_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/entities/WorkflowStateInformation.cs", "_workflow_state_information_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/Properties/AssemblyInfo.cs", "_assembly_info_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/UploadHelper/HttpUploadHelper.cs", "_http_upload_helper_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/UploadHelper/MimePart.cs", "_mime_part_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/UploadHelper/StreamMimePart.cs", "_stream_mime_part_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/UploadHelper/StringMimePart.cs", "_string_mime_part_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/UploadHelper/UploadFile.cs", "_upload_file_8cs.html", null ],
      [ "V:/NightlyBuild/Cumulus_10.2.x/build/CJCApps/CIP/cip-sdk/dotnet/CIP.lib/utils/Separator.cs", "_separator_8cs.html", null ]
    ] ]
  ] ]
];

function createIndent(o,domNode,node,level)
{
  if (node.parentNode && node.parentNode.parentNode)
  {
    createIndent(o,domNode,node.parentNode,level+1);
  }
  var imgNode = document.createElement("img");
  if (level==0 && node.childrenData)
  {
    node.plus_img = imgNode;
    node.expandToggle = document.createElement("a");
    node.expandToggle.href = "javascript:void(0)";
    node.expandToggle.onclick = function() 
    {
      if (node.expanded) 
      {
        $(node.getChildrenUL()).slideUp("fast");
        if (node.isLast)
        {
          node.plus_img.src = node.relpath+"ftv2plastnode.png";
        }
        else
        {
          node.plus_img.src = node.relpath+"ftv2pnode.png";
        }
        node.expanded = false;
      } 
      else 
      {
        expandNode(o, node, false);
      }
    }
    node.expandToggle.appendChild(imgNode);
    domNode.appendChild(node.expandToggle);
  }
  else
  {
    domNode.appendChild(imgNode);
  }
  if (level==0)
  {
    if (node.isLast)
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2plastnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2lastnode.png";
        domNode.appendChild(imgNode);
      }
    }
    else
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2pnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2node.png";
        domNode.appendChild(imgNode);
      }
    }
  }
  else
  {
    if (node.isLast)
    {
      imgNode.src = node.relpath+"ftv2blank.png";
    }
    else
    {
      imgNode.src = node.relpath+"ftv2vertline.png";
    }
  }
  imgNode.border = "0";
}

function newNode(o, po, text, link, childrenData, lastNode)
{
  var node = new Object();
  node.children = Array();
  node.childrenData = childrenData;
  node.depth = po.depth + 1;
  node.relpath = po.relpath;
  node.isLast = lastNode;

  node.li = document.createElement("li");
  po.getChildrenUL().appendChild(node.li);
  node.parentNode = po;

  node.itemDiv = document.createElement("div");
  node.itemDiv.className = "item";

  node.labelSpan = document.createElement("span");
  node.labelSpan.className = "label";

  createIndent(o,node.itemDiv,node,0);
  node.itemDiv.appendChild(node.labelSpan);
  node.li.appendChild(node.itemDiv);

  var a = document.createElement("a");
  node.labelSpan.appendChild(a);
  node.label = document.createTextNode(text);
  a.appendChild(node.label);
  if (link) 
  {
    a.href = node.relpath+link;
  } 
  else 
  {
    if (childrenData != null) 
    {
      a.className = "nolink";
      a.href = "javascript:void(0)";
      a.onclick = node.expandToggle.onclick;
      node.expanded = false;
    }
  }

  node.childrenUL = null;
  node.getChildrenUL = function() 
  {
    if (!node.childrenUL) 
    {
      node.childrenUL = document.createElement("ul");
      node.childrenUL.className = "children_ul";
      node.childrenUL.style.display = "none";
      node.li.appendChild(node.childrenUL);
    }
    return node.childrenUL;
  };

  return node;
}

function showRoot()
{
  var headerHeight = $("#top").height();
  var footerHeight = $("#nav-path").height();
  var windowHeight = $(window).height() - headerHeight - footerHeight;
  navtree.scrollTo('#selected',0,{offset:-windowHeight/2});
}

function expandNode(o, node, imm)
{
  if (node.childrenData && !node.expanded) 
  {
    if (!node.childrenVisited) 
    {
      getNode(o, node);
    }
    if (imm)
    {
      $(node.getChildrenUL()).show();
    } 
    else 
    {
      $(node.getChildrenUL()).slideDown("fast",showRoot);
    }
    if (node.isLast)
    {
      node.plus_img.src = node.relpath+"ftv2mlastnode.png";
    }
    else
    {
      node.plus_img.src = node.relpath+"ftv2mnode.png";
    }
    node.expanded = true;
  }
}

function getNode(o, po)
{
  po.childrenVisited = true;
  var l = po.childrenData.length-1;
  for (var i in po.childrenData) 
  {
    var nodeData = po.childrenData[i];
    po.children[i] = newNode(o, po, nodeData[0], nodeData[1], nodeData[2],
        i==l);
  }
}

function findNavTreePage(url, data)
{
  var nodes = data;
  var result = null;
  for (var i in nodes) 
  {
    var d = nodes[i];
    if (d[1] == url) 
    {
      return new Array(i);
    }
    else if (d[2] != null) // array of children
    {
      result = findNavTreePage(url, d[2]);
      if (result != null) 
      {
        return (new Array(i).concat(result));
      }
    }
  }
  return null;
}

function initNavTree(toroot,relpath)
{
  var o = new Object();
  o.toroot = toroot;
  o.node = new Object();
  o.node.li = document.getElementById("nav-tree-contents");
  o.node.childrenData = NAVTREE;
  o.node.children = new Array();
  o.node.childrenUL = document.createElement("ul");
  o.node.getChildrenUL = function() { return o.node.childrenUL; };
  o.node.li.appendChild(o.node.childrenUL);
  o.node.depth = 0;
  o.node.relpath = relpath;

  getNode(o, o.node);

  o.breadcrumbs = findNavTreePage(toroot, NAVTREE);
  if (o.breadcrumbs == null)
  {
    o.breadcrumbs = findNavTreePage("index.html",NAVTREE);
  }
  if (o.breadcrumbs != null && o.breadcrumbs.length>0)
  {
    var p = o.node;
    for (var i in o.breadcrumbs) 
    {
      var j = o.breadcrumbs[i];
      p = p.children[j];
      expandNode(o,p,true);
    }
    p.itemDiv.className = p.itemDiv.className + " selected";
    p.itemDiv.id = "selected";
    $(window).load(showRoot);
  }
}

