                               README

                     Canto Integration Platform
 
                    Microsoft .Net Client Library
                    Microsoft .Net Example Project

The Canto Integration Platform consists of a server component and SDKs for
developing client-side code. The server component is a web application that
is deployed into a web application container (e.g. Apache Tomcat).
The client SDK consists of libraries, sample code and example projects for
different programming environments:

- Microsoft .Net (C#)
- Adobe Flash/ActionScript
- PHP
- Java
- JavaScript
- Apple iOS (Objective-C)
- Google Android (Android-Java)

================================================================================
    License Conditions
================================================================================
Permission is hereby granted, free of charge, to any person obtaining a copy of
this SDK, to deal in the Software without restriction, including without
limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom
the Software is furnished to do so, subject to the following conditions:
The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

The SDK includes source code from http://aspnetupload.com
  Licensed under a Creative Commons Attribution-Share Alike 3.0 United States License
  http://creativecommons.org/licenses/by-sa/3.0/us/
  Copyright © 2009 Krystalware, Inc.
================================================================================
    System Requirements
================================================================================
.Net Runtime 3.5 or later
Microsoft Developer Studio 2010

================================================================================
    Contents
================================================================================
This SDK consists of the following folders:

doc
   Technical documentation of the CIP library

lib
   The CIP library and inline (XML) documentation
   The Newtonsoft JSON library

examples
   Example projects including source code

================================================================================
    Getting Started
================================================================================

You can learn how to write CIP client side code by opening the example project
or you build your own project and include the DLLs you find in the "lib" folder
as references.

Copyright (c) 2012, Canto GmbH