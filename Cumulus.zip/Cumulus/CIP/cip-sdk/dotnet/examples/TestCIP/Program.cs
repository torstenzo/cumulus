﻿using System;
using System.Collections.Generic;
using System.Globalization;
using Canto.Cip.Client.Views;
using Canto.Cip.Lib.Constants;
using Canto.Cip.Lib.Entities;

////////////////////////////////////////////////////////////////////////////////
//
//  CANTO INTEGRATION PLATFORM
//  Copyright 2013 Canto GmbH
//  All Rights Reserved.
//
//	NOTICE: Canto GmbH permits you to use, modify, and distribute this file
//  in accordance with the terms of the license agreement accompanying it.
//
////////////////////////////////////////////////////////////////////////////////

namespace Canto.Cip.Lib.Test
{
    class Program
    {
        private static String BaseUrl = "http://localhost:8080/CIP"; // Base URL for all CIP requests
        private static String Catalog = "sample";                    // "alias name" of a catalog configured in the CIP server
        private static String View = "fields";                       // Name of the view configured in the CIP server

        private static CIPManager cipManager = null;

        static void Main (String[] args)
        {
            QueryResult result;
            DateTime startTime = DateTime.Now;
            cipManager = new CIPManager (BaseUrl, "Canto.Cip.Client.Views");
            Console.WriteLine ("Testing Canto CIP from .NET");

            String user = "cumulus";
            String password = "cumulus";
            String serverAddress = "localhost";
            // Open a session passing login name "cumulus" and password "cumulus"
            // If these credentials are wrong this call will not fail but the first request accessing a catalog
            CultureInfo locale = new CultureInfo ("en");
            //CIPSession session = cipManager.OpenSession (locale, user, password, null, null, 300000);
            CIPSession session = cipManager.OpenSession ();
            //session.Locale = locale;

            try
            {
                User userInfo = cipManager.getUserInformation(session, user, password, serverAddress);
                Console.WriteLine("User Information =" + userInfo.ToString());

                Dictionary<string, WorkflowInformation> workflows = cipManager.getWorkflowInformation (session, Catalog, user, password, serverAddress, null);
                foreach (KeyValuePair<string, WorkflowInformation> entry in workflows)
                {
                    foreach (int activityID in entry.Value.Activities)
                    {
                        WorkflowActivityInformation workflowEventInformation = cipManager.getWorkflowActivityInformation(session, Catalog, user, password, serverAddress, null, entry.Key, activityID);
                        string n = workflowEventInformation.Name;

                    }
                    foreach (int stateID in entry.Value.States)
                    {
                        WorkflowStateInformation workflowStateInformation = cipManager.getWorkflowStateInformation(session, Catalog, user, password, serverAddress, null, entry.Key, stateID);
                        string n = workflowStateInformation.Name;

                    }
                }
                string query = cipManager.getWorkflowTodoQuery (session, Catalog, user, password, serverAddress, null);
//                WorkflowItemInformation workflowItemInformation = cipManager.getItemWorkflowState(session, Catalog, 45190, user, password, serverAddress, null);
//                IList<string> dynamicAssignments = new List<string>();
//                dynamicAssignments.Add ("U:{98ca1422-0171-4d1d-8b84-8cdda4ab70ae}:cumulus");
//                cipManager.applyItemWorkflowEvent(session, Catalog, 45190, "{c785b8fd-f944-43d0-a504-df23982ef471}", 1000000004, 1000000009, dynamicAssignments, null, null, null, null);

                Dictionary<String, Object> myConfig = cipManager.GetClientConfiguration (session, "com.canto.cumulus.client.sample");

                DateTime startDateTime = DateTime.Now;
                startDateTime = startDateTime.AddDays (-10);

                Dictionary<String, IList<int>> stats = cipManager.GetFieldStatistics (session, Catalog, startDateTime, 10, new List<String> { "Asset Modification Date", "Asset Creation Date" });

                IList<UserCommentsThread> threadsList = cipManager.GetItemCommentsThreads (session, Catalog, 176);
                UserCommentsThread thread = cipManager.GetThreadComments (session, Catalog, 2);

                /* Import an asset */
                FieldsView newItem = new FieldsView ();
              
                // The Name can be overwritten in the UploadItem
                newItem.Name = "importtest.jpg";

                UploadItem uploadItem = new UploadItem(newItem, "c:\\tmp\\importtest.jpg", false);
                long? itemId = cipManager.ImportAsset (session, Catalog, View, uploadItem, null);
                Console.WriteLine("Created an asset with id="+ itemId);

                // Get categories by path
                DamCategoriesList catList = cipManager.GetCategoriesByPath (session, Catalog, "categories", "$Categories:By Project:Berlin");

                //Create a category by path
                long? catId = cipManager.CreateCategoryByPath (session, Catalog, "level1", "$Categories");

                catId = cipManager.CreateCategoryByPath (session, Catalog, "$Categories:level1:test::2");
                catId = cipManager.CreateCategoryByPath (session, Catalog, "$Categories:level1:test::2::3");
                catId = cipManager.CreateCategoryByPath (session, Catalog, "$Categories:level1:test-2");

                //Search by category
                QueryResult AllAssets = cipManager.SearchByCategory (session, Catalog, "fields", "Categories", 0, true, null, null, null);

                AllAssets = cipManager.SearchByCategory (session, Catalog, "fields", "Categories", 0, true, null, "\"Record Name\" ? JPG", null, null, null, null, null, null, null, null);

                cipManager.PurgePreviewCacheByItemID (session, Catalog, 200);

                string queryFilter = "\"{af4b2e02-5f6a-11d2-8f20-0000c0e166dc}:Record Modification Date\" > \"2011-01-01\"";
                AllAssets = cipManager.Search (session, Catalog, "fields", queryFilter, null, null, null);

                AllAssets = cipManager.Search (session, Catalog, "fields", null, null, queryFilter, null, null, null, null, null, null, null, null, null);

                /*
                IfExists? ifExists = IfExists.Error;
                String locationDirectory = "mylocation/test.net1/tt";
                String location = cipManager.StorePreviewImage (session, Catalog, 228, null, null, null, null, null, null, 100, null, null, null, locationDirectory, "mytestname.jpg", ifExists, null, null, null, null, null, null);

                location = cipManager.StoreThumbnailImage (session, Catalog, 228, 400, null, null, null, null, locationDirectory, "mythumbnail.jpg", ifExists, null, null, null, null, null);

                location = cipManager.DownloadAssetToLocation (session, Catalog, 228, locationDirectory, null, ifExists, null, null, null, null, null);

                location = cipManager.DownloadAssetToLocation (session, Catalog, 228, locationDirectory, "testname.pdf", ifExists, null, null, null, null, null);
                */
                IList<DamKeyValue> catalogs = cipManager.GetCatalogs (session, user, password, serverAddress);

              /* Example gui form 
                PreviewFrame form = new PreviewFrame (cipManager, session);
                form.ShowDialog ();
              */

                AllAssets = cipManager.QuickSearch (session, Catalog, "fields", "zebra", null, null, null);
                AllAssets = cipManager.Search(session, Catalog, "fields", "\"{af4b2e00-5f6a-11d2-8f20-0000c0e166dc}:Record Name\" ? JPG", null, null, null);

                // Perform a quick search Uisng "zebra" as the search String
                result = cipManager.QuickSearch (session, Catalog, View, "zebra", null, null, null);
                PrintQueryResult (result);

                SortFieldDescriptor recordNameSortDesc = new SortFieldDescriptor("{af4b2e00-5f6a-11d2-8f20-0000c0e166dc}:Record Name", SortDirection.Descending);
                SortFieldDescriptor recordNameSortAsc = new SortFieldDescriptor("{af4b2e00-5f6a-11d2-8f20-0000c0e166dc}:Record Name", SortDirection.Ascending);
                SortFieldDescriptor idSortDesc = new SortFieldDescriptor ("id", SortDirection.Descending);

                IList<SortFieldDescriptor> sortList = new List<SortFieldDescriptor> ();
                sortList.Add (recordNameSortDesc);

                ServiceVersion serviceVersion = cipManager.GetVersion (session);
                Console.WriteLine (serviceVersion.ToString ());

                IList<long> related = cipManager.GetRelatedAssets (session, Catalog, 137, Relation.IsVariantMasterOf);

                String queryString = "\"{af4b2e00-5f6a-11d2-8f20-0000c0e166dc}:Record Name\" ? JPG";   // To find all records where the field "Record Name" contains "JPG"

                // Perform a search with the query String
                result = cipManager.Search (session, Catalog, View, queryString, null, null, null);
                PrintQueryResult (result);

                // Perform combined search with the query String and quick search string
                result = cipManager.Search (session, Catalog, View, queryString, null, null, null);
                PrintQueryResult (result);

                // Use fields array in place of the view
                IList<String> fieldsArray = new List<String> ();
                fieldsArray.Add("notes:{af4b2e0b-5f6a-11d2-8f20-0000c0e166dc}:Notes");
                fieldsArray.Add("winref:{af4b2e16-5f6a-11d2-8f20-0000c0e166dc}:Asset Reference/Windows");
                fieldsArray.Add("hpix:{05f6f3f0-833a-45a0-ade4-8e48542f37ef}:Horizontal Pixels");
                fieldsArray.Add("camid:{745e9161-62c2-11d4-909c-0080ad80c556}:Camera ID");
                fieldsArray.Add("stat:{af4b2e07-5f6a-11d2-8f20-0000c0e166dc}:Status");
                result = cipManager.Search (session, Catalog, null, "zebra", null, null, null, null, null, null, fieldsArray, null, null, null, null);
                if (result.Items != null)
                {
                    foreach (DamItem damItem in result.Items)
                    {
                        foreach (String field in fieldsArray)
                        {
                            string[] splitField = field.Split(new Char[] { ':' });
                            string fieldAlias = splitField[0];
                            if (damItem.Fields.ContainsKey(fieldAlias))
                            {
                                switch (fieldAlias)
                                {
                                    case "notes":
                                    case "winref":
                                    case "camid":
                                        Console.Write("{0}:{1} ", fieldAlias, damItem.getStringFieldValue(fieldAlias));
                                        break;
                                    case "hpix":
                                        Console.Write("{0}:{1} ", fieldAlias, damItem.getIntegerFieldValue(fieldAlias));
                                        break;
                                    case "stat":
                                        Console.Write("{0}:{1} ", fieldAlias, damItem.getStringListFieldValue(fieldAlias));
                                        break;

                                }
                            }
                        }
                        Console.WriteLine();
                    }
                }

                //Get the field values for the first item found by the above search
                // Use the generated wrapper class "FieldsView" which wraps the field values for the configured view called "fields"
                long? id = result.Items[0].ID;
                FieldsView item = cipManager.GetFieldValues (session, Catalog, View, id) as FieldsView;
                if (item != null)
                {
                    //Print out the field values
                    Console.WriteLine ("Before");
                    PrintItem (item);

                    //Remember current status id in the local variable
                    DamStringListValue oldStatus = item.Status;


                    // Change status to 'Approved'
                    //item.Status = new DamStringListValue ((long?) FieldsView.StatusEnum.Approved, null);
                    item.Status = new DamStringListValue { ID = (long?)FieldsView.StatusEnum.Rejected};// ((long?)FieldsView.StatusEnum.Approved, null);

                    // Store changed status on the server
                    cipManager.SetFieldValues (session, Catalog, new List<DamItem> { item });

                    //refresh the item from the server
                    item = cipManager.GetFieldValues (session, Catalog, View, id) as FieldsView;
                    Console.WriteLine ("After");
                    PrintItem (item);


                    Console.WriteLine ("Restore old status");

                    // reset status to the previous value
                    item.Status = oldStatus;

                    //store the status on the server
                    cipManager.SetFieldValues (session, Catalog, new List<DamItem> { item });

                    //refresh the item from the server
                    item = cipManager.GetFieldValues (session, Catalog, View, id) as FieldsView;
                    Console.WriteLine ("Restored old status");
                    PrintItem (item);

                    // Assign item to category 12
                    Console.WriteLine ("Before Assign");
                    PrintItem (item);
                    cipManager.AssignToCategory (session, Catalog, item.ID, 12);
                    Console.WriteLine ("After Assign");
                    item = cipManager.GetFieldValues (session, Catalog, View, id) as FieldsView;
                    PrintItem (item);

                    // Detach item from category 12
                    Console.WriteLine ("Before Detach");
                    PrintItem (item);
                    cipManager.DetachFromCategory (session, Catalog, item.ID, 12);
                    Console.WriteLine ("After Detach");
                    item = cipManager.GetFieldValues (session, Catalog, View, id) as FieldsView;
                    PrintItem (item);
                }

                Console.WriteLine ("");
                Console.WriteLine ("Categories tree");
                // Get all categories recursivelly
                DamCategoriesList categoriesList = cipManager.GetCategories (session, Catalog, "categories", CIPManager.CATEGORIES_ALL_LEVELS);
                PrintCategoriesTree (categoriesList, "-");


                Console.WriteLine ("");
                Console.WriteLine ("Print out all tables:");
                // Gets all tables
                IList<String> allTables = cipManager.GetTables (session, Catalog);
                foreach (String table in allTables)
                {
                    Console.WriteLine (table);
                }

                Console.WriteLine ("");
                Console.WriteLine ("Layout details for view {0}:", View);
                // The layout of the filds collection defined in the view
                IList<DamLayoutField> layoutFields = cipManager.GetLayout (session, Catalog, View);
                foreach (DamLayoutField layout in layoutFields)
                {
                    Console.WriteLine (layout.ToString ());
                }

                /** Send collection link*/
                DateTime expirationDate = DateTime.Now;
                expirationDate = expirationDate.AddDays (5);

                Boolean isAdded = cipManager.SendCollectionLink (session, Catalog, null, new List<long> { 137, 138, 139, 140 }, "myCollectionLink", null, expirationDate, null, "http://localhost:8080/Sites",
                    new List<LinkPermission> { LinkPermission.CanDownload, LinkPermission.CanOpenInfoWindow, LinkPermission.CanPreview, LinkPermission.CanPrint }, "linkCollection", "mailFrom@myhost.com",
                    new List<String> { "user1@host", "user2@host" }, "Great collection", null);
                if (isAdded)
                {
                    Console.WriteLine ("Collection link sent");
                }
                /*    */

                /* Version information for vault assets only
                 * 
                    DamItemVersionInformation allVersions = cipManager.GetItemVersions (session, Catalog, 15867);
                    Console.WriteLine (allVersions.ToString ());
                 * 
                 */

                //list a directory c:\windows on the server
                /**
                 * Enable the "file" protocol in cip-config.xml before running the following code
                 * 
                    Console.Write (cipManager.ListLocation (session, "file://c:/windows/").ToString ());
                 */

                /** Autopurge preview cache  test
                    queryString = "\"Record Name\" ? .";   // To find all records where the field "Record Name" contains "."

                    // Perform a search with the query String
                    result = cipManager.Search (session, Catalog, null, queryString, null, null, null);
                    foreach (long itemId in result.ItemIds)

                    {
                        for (int k = 10; k < 300; k = k + 3)
                            cipManager.GetPreviewImage (session, Catalog, itemId, null, k, true);
                    }
                 */
            }
            catch (DamException e)
            {
                Console.WriteLine ("Error: {0}", e.ToString ());
            }
            finally
            {
                // Close an open session
                if (cipManager != null && session != null)
                {
                    cipManager.CloseSession (session);
                }
            }

            // wait so that results can be viewed
            Console.WriteLine ("");
            PrintDuration (startTime);
            Console.WriteLine ("");
            Console.Write ("Hit <return> to terminate...");
            Console.ReadLine ();
        }

        private static void PrintDuration (DateTime startTime)
        {
            DateTime stopTime = DateTime.Now;
            TimeSpan duration = stopTime - startTime;
            Console.WriteLine (duration);
            Console.WriteLine ("");
        }

        private static void PrintQueryResult (QueryResult result)
        {
            Console.WriteLine ("Found {0} records", result.TotalCount);
            if (result.CollectionName != null)
            {
                Console.WriteLine ("Using collection {0}", result.CollectionName);
            }
            if (result.Items != null)
            {
                foreach (DamItem damItem in result.Items)
                {
                    FieldsView item = damItem as FieldsView;
                    PrintItem (item);
                }
            }
        }

        private static void PrintItem (FieldsView item)
        {
            long? id = item.ID;
            DateTime? date = item.RecordModificationDate;
            if (date != null)
            {
                date = ((DateTime)item.RecordModificationDate).ToLocalTime ();
            }

            Console.WriteLine ("id: {0}, Name: \"{1}\", RecordModificationDate (LocalTime): {2}, Status: {3}, RecordModificationDate: {4}",
                                item.ID, item.Name, date, item.Status, item.RecordModificationDate);

            Console.WriteLine ("RecordName: {0}, Rating: {1}",
                                item.RecordName, item.Rating);
            if (item.AssetReference != null)
            {
                foreach (DamBinaryValue v in item.AssetReference)
                {
                    Console.WriteLine ("AssetReference: {0}", v.DisplayString);
                }
            }
            if (item.Categories != null)
            {
                foreach (DamCategoryValue v in item.Categories)
                {
                    Console.WriteLine ("Category: {0}", v.Name);
                }
            }
            Console.WriteLine ("------------------------------------------------------------");
        }

        private static void PrintCategoriesTree (DamCategoriesList categoriesList, String indent)
        {
            CategoriesView categories = categoriesList.Data as CategoriesView;
            Console.WriteLine ("{0}{1}-{2}", indent + "+|", categories.ID, categories.CategoryName);
            indent += "-";
            foreach (DamCategoriesList category in categoriesList.Children)
            {
                PrintCategoriesTree (category, indent);
            }
        }
    }
}
