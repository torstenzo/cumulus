﻿using System;
using System.Collections.Generic;
using Canto.Cip.Lib;
using Canto.Cip.Lib.Entities;

using Newtonsoft.Json;

////////////////////////////////////////////////////////////////////////////////
//
//  CANTO INTEGRATION PLATFORM
//  Copyright 2011 Canto GmbH
//  All Rights Reserved.
//
//	NOTICE: Canto GmbH permits you to use, modify, and distribute this file
//  in accordance with the terms of the license agreement accompanying it.
//
////////////////////////////////////////////////////////////////////////////////

namespace Canto.Cip.Client.Views
{
    /// <summary>
    /// Auto generated class 
    /// http://CIP-Server:CIP-Port/CIP/developer/describe/sample/categories?locale=en&table=Categories
    /// </summary>
    [JsonObject (MemberSerialization.OptIn)]
    public class CategoriesView : DamItem
    {
        public const string ViewName = "categories";


        private const string CategoryNameKey = "Category Name";

        private string _CategoryName;


        [JsonProperty (PropertyName = CategoryNameKey)]
        public string CategoryName
        {
            get { return _CategoryName; }
            set { _CategoryName = value; }
        }


        public override void OnDeserialized ()
        {
            base.OnDeserialized ();
            CategoryName = getStringFieldValue (CategoryNameKey);
        }


        public override void OnSerializing ()
        {
            setStringFieldValue (CategoryNameKey, CategoryName);
            base.OnSerializing ();
        }

    }
}

