﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Canto.Cip.Lib;

////////////////////////////////////////////////////////////////////////////////
//
//  CANTO INTEGRATION PLATFORM
//  Copyright 2011 Canto GmbH
//  All Rights Reserved.
//
//	NOTICE: Canto GmbH permits you to use, modify, and distribute this file
//  in accordance with the terms of the license agreement accompanying it.
//
////////////////////////////////////////////////////////////////////////////////

namespace Canto.Cip.Lib.Test
{
    public partial class PreviewFrame : Form
    {
        private static CIPManager cipManager = null;
        private static string catalog = "sample";
        private static CIPSession session = null;

        public PreviewFrame (CIPManager cipManagerLoc, CIPSession sessionLoc)
        {
            InitializeComponent ();
            cipManager = cipManagerLoc;
            session = sessionLoc;
            pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
            comboBox1.SelectedIndex = 0;
        }

        private void button1_Click (object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty (textBox1.Text))
            {
                int? id = Int32.Parse (textBox1.Text);
                Image image = null;
                int maxSize = 255;
                try
                {
                    if (!String.IsNullOrEmpty (maxSizeTextBox.Text))
                    {
                        try
                        {
                            maxSize = int.Parse (maxSizeTextBox.Text);
                        }
                        catch
                        {
                        }
                    }
                    if (maxSize < 10 || maxSize > 2000)
                    {
                        maxSize = 255;
                        maxSizeTextBox.Text = maxSize.ToString ();
                    }

                    if (comboBox1.SelectedIndex == 1)
                    {
                        image = cipManager.GetThumbnailImage (session, catalog, id, maxSize, null);
                    }
                    else
                    {
                        image = cipManager.GetPreviewImage (session, catalog, id, null, maxSize, true);
                    }
                    
                }
                catch{};
                if (image != null)
                {
                    pictureBox1.Image = image;
                }

            }
        }

        private void pictureBox1_Click (object sender, EventArgs e)
        {

        }
    }
}
