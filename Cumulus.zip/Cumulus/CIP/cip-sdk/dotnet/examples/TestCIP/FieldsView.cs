using System;
using System.Collections.Generic;
using Canto.Cip.Lib;
using Canto.Cip.Lib.Entities;

using Newtonsoft.Json;

namespace Canto.Cip.Client.Views
{
    [JsonObject(MemberSerialization.OptIn)]
    public class FieldsView : DamItem
    {
        public const string ViewName = "fields";


        private const string RecordNameKey = "RecordName";
        private const string RecordModificationDateKey = "RecordModificationDate";
        private const string FileFormatKey = "FileFormat";
        private const string StatusKey = "Status";
        private const string IPTCDescriptionKey = "IPTCDescription";
        private const string RatingKey = "Rating";
        private const string NotesKey = "Notes";
        private const string CategoriesKey = "Categories";
        private const string AssetDataSizeLongKey = "AssetDataSizeLong";
        private const string AssetModificationDateKey = "AssetModificationDate";
        private const string AssetReferenceKey = "AssetReference";

        private string _RecordName;
        private DateTime? _RecordModificationDate;
        private string _FileFormat;
        private DamStringListValue _Status;
        private string _IPTCDescription;
        private DamRatingValue _Rating;
        private string _Notes;
        private IList<DamCategoryValue> _Categories;
        private DamDataSizeValue _AssetDataSizeLong;
        private DateTime? _AssetModificationDate;
        private IList<DamBinaryValue> _AssetReference;


        [JsonProperty(PropertyName = RecordNameKey)]
        public string RecordName
        {
            get { return _RecordName; }
            set { _RecordName = value; }
        }


        [JsonProperty(PropertyName = RecordModificationDateKey)]
        public DateTime? RecordModificationDate
        {
            get { return _RecordModificationDate; }
            set { _RecordModificationDate = value; }
        }


        [JsonProperty(PropertyName = FileFormatKey)]
        public string FileFormat
        {
            get { return _FileFormat; }
            set { _FileFormat = value; }
        }


        [JsonProperty(PropertyName = StatusKey)]
        public DamStringListValue Status
        {
            get { return _Status; }
            set { _Status = value; }
        }


        [JsonProperty(PropertyName = IPTCDescriptionKey)]
        public string IPTCDescription
        {
            get { return _IPTCDescription; }
            set { _IPTCDescription = value; }
        }


        [JsonProperty(PropertyName = RatingKey)]
        public DamRatingValue Rating
        {
            get { return _Rating; }
            set { _Rating = value; }
        }


        [JsonProperty(PropertyName = NotesKey)]
        public string Notes
        {
            get { return _Notes; }
            set { _Notes = value; }
        }


        [JsonProperty(PropertyName = CategoriesKey)]
        public IList<DamCategoryValue> Categories
        {
            get { return _Categories; }
            set { _Categories = value; }
        }


        [JsonProperty(PropertyName = AssetDataSizeLongKey)]
        public DamDataSizeValue AssetDataSizeLong
        {
            get { return _AssetDataSizeLong; }
            set { _AssetDataSizeLong = value; }
        }


        [JsonProperty(PropertyName = AssetModificationDateKey)]
        public DateTime? AssetModificationDate
        {
            get { return _AssetModificationDate; }
            set { _AssetModificationDate = value; }
        }


        [JsonProperty(PropertyName = AssetReferenceKey)]
        public IList<DamBinaryValue> AssetReference
        {
            get { return _AssetReference; }
            set { _AssetReference = value; }
        }


        public override void OnDeserialized()
        {
            base.OnDeserialized();
            RecordName = getStringFieldValue(RecordNameKey);
            RecordModificationDate = getDateTimeFieldValue(RecordModificationDateKey);
            FileFormat = getStringFieldValue(FileFormatKey);
            Status = getStringListFieldValue(StatusKey);
            IPTCDescription = getStringFieldValue(IPTCDescriptionKey);
            Rating = getRatingFieldValue(RatingKey);
            Notes = getStringFieldValue(NotesKey);
            Categories = getCategoriesFieldValue(CategoriesKey);
            AssetDataSizeLong = getDataSizeFieldValue(AssetDataSizeLongKey);
            AssetModificationDate = getDateTimeFieldValue(AssetModificationDateKey);
            AssetReference = getBinaryListFieldValue(AssetReferenceKey);
        }


        public override void OnSerializing()
        {
            setStringFieldValue(RecordNameKey, RecordName);
            setDateTimeFieldValue(RecordModificationDateKey, RecordModificationDate);
            setStringFieldValue(FileFormatKey, FileFormat);
            setStringListFieldValue(StatusKey, Status);
            setStringFieldValue(IPTCDescriptionKey, IPTCDescription);
            setRatingFieldValue(RatingKey, Rating);
            setStringFieldValue(NotesKey, Notes);
            setCategoriesFieldValue(CategoriesKey, Categories);
            setDataSizeFieldValue(AssetDataSizeLongKey, AssetDataSizeLong);
            setDateTimeFieldValue(AssetModificationDateKey, AssetModificationDate);
            setBinaryListFieldValue(AssetReferenceKey, AssetReference);
            base.OnSerializing();
        }

        public enum StatusEnum : long
        {
            Approved = 0,
            NeedsApproval = 1,
            Rejected = 2
        }

    }
}
